<div class="wrap p-t-0">
    <footer class="app-footer">
      
        <div class="copyright pull-left">Doctor Appointment Web App </div>
   
    </footer>
  </div>